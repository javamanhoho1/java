package Ŭ����;

public class Dog {

	
	
	String color;
	int tall;
	public void eat() {
		System.out.println("�Դ�");
	}
	public void sleep() {
		System.out.println("�ڴ�");
	}
}
