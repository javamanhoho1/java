package Ŭ����;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ī��Ʈ {
	static int count = 0;
	private static JTextField t1;
	private static JTextField t2;

	public static void main(String[] args) {
		// �����Ӻ�ǰ1
	
		JLabel result = new JLabel("0");
		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(0, 128, 128));
		f.setTitle("���� ī����");
		f.setSize(343, 594);
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel_1 = new JLabel("\uC22B\uC7901");
		f.getContentPane().add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setBackground(new Color(238, 232, 170));
		t1.setForeground(new Color(0, 0, 255));
		t1.setFont(new Font("����", Font.PLAIN, 35));
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\uC22B\uC7902");
		f.getContentPane().add(lblNewLabel_2);
		
		t2 = new JTextField();
		t2.setBackground(new Color(238, 232, 170));
		t2.setForeground(new Color(0, 0, 255));
		t2.setFont(new Font("����", Font.PLAIN, 35));
		f.getContentPane().add(t2);
		t2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\\uD559\uC0DD\uBC29\\duthezi\\day04\\\uACC4\uC0B0\uAE30.png"));
		f.getContentPane().add(lblNewLabel);
		
		JButton result1 = new JButton("-");
		result1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("-�� �����̱���");
				//count--;
				result.setText(count+"");
				String s1 = t1.getText();
				String s2 = t2.getText();
				System.out.println(s1 + ", " + s2);
				int n1 = Integer.parseInt(s1);
				int n2 = Integer.parseInt(s2);
				int n3 = n1 - n2;
				result.setText(n3+"");
			}
		});
		result1.setBackground(Color.BLUE);
		result1.setForeground(Color.PINK);
		result1.setFont(new Font("����", Font.PLAIN, 99));
		f.getContentPane().add(result1);
		
		JButton btnNewButton_1 = new JButton("0");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("0�� �����̱���");
				//count = 0;
				result.setText(0+"");
				t1.setText("");
				t2.setText("");
				
				
			
				
			}
		});
		btnNewButton_1.setBackground(new Color(255, 215, 0));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 99));
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("+");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("+�� �����̱���");
				//count++;
				//�ΰ��� ���ڰ� ��������
				String s1 = t1.getText();
				String s2 = t2.getText();
				System.out.println(s1 + ", " + s2);
				int n1 = Integer.parseInt(s1);
				int n2 = Integer.parseInt(s2);
				int n3 = n1 + n2;
				result.setText(n3+"");
				
				
				//��� �Է°�  ��Ʈ��->��Ʈ �� ��ȯ�ϱ�
				//+����
				//result�� ���
				
			}
		});
		btnNewButton_2.setBackground(Color.DARK_GRAY);
		btnNewButton_2.setForeground(Color.GREEN);
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 99));
		f.getContentPane().add(btnNewButton_2);
		
		result.setBackground(Color.ORANGE);
		result.setForeground(Color.CYAN);
		result.setFont(new Font("����", Font.PLAIN, 99));
		f.getContentPane().add(result);
		// ��ġ��ǰ1, �� ��ǰ2, �̹��� ��ǰ1, ��ư ��ǰ3
		
		
		
		
		
		
		
		
		f.setVisible(true);
	}

}
