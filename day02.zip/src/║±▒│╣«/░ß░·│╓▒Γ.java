package �񱳹�;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ����ֱ� {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setTitle("���� �׷���");
		f.setSize(500, 500);
		
		JButton top = new JButton("\uC704\uC5D0 \uBC84\uD2BC");
		JButton sub = new JButton("\uC544\uB798 \uBC84\uD2BC");
		JButton middle = new JButton("\uAC00\uC6B4\uB370 \uBC84\uD2BC");
		top.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("ž����");
				f.setTitle("ž����");
				sub.setText("ž����");
				middle.setText("ž����");
			}
		});
		f.getContentPane().add(top, BorderLayout.NORTH);
		
		middle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("�̵崩��");
				f.setTitle("�̵崩��");
			}
		});
		f.getContentPane().add(middle, BorderLayout.CENTER);
		
		sub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("���괩��");
				f.setTitle("���괩��");
			}
		});
		f.getContentPane().add(sub, BorderLayout.SOUTH);
		
		
		
		
		f.setVisible(true);
	}

}
